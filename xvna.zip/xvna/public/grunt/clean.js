module.exports = {
  angular: ['angular/*']
};
