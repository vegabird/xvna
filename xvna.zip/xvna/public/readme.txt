1: Please put the files on a server or local host to preview. 

then preview:  
http://localhost:8080/app/
http://localhost:8080/app/index-hospital.html
http://localhost:8080/app/index-university.html
http://localhost:8080/app/index-crm.html
http://localhost:8080/app/index-music.html
http://localhost:8080/app/index-freelancing.html
http://localhost:8080/app/index-socialmedia.html
http://localhost:8080/app/index-ecommerce.html
http://localhost:8080/app/index-blog.html

2: Use Grunt and Bower

install node.js
go to the app root

>npm install -g grunt-cli
>npm install
>bower install (to update bower dependencies)
>npm start

> grunt build:angular
to build the 'angular' folder
