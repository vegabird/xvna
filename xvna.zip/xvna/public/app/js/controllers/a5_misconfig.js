app.controller('a5_misconfig_ctrl', ['$scope', function($scope) {
  

}]);
